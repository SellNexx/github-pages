const capabilities = [
  ["Multiple management consoles", "Switching between vendor-specific tools to manage one network wastes time and fragments ownership."],
  ["Limited network visibility", "Without a single source of truth, it's hard to see device health and status across the whole estate."],
  ["Slow issue detection", "Scattered alerts and manual checks delay the moment a real issue gets in front of the right person."],
];

const tools = [
  "Network Monitoring",
  "Multi-Vendor Management",
  "Device Management",
  "Network Discovery",
  "Performance Monitoring",
  "Real-Time Alerts",
  "Network Topology",
  "Centralized Dashboard",
  "Reporting & Analytics",
  "User & Role Management",
  "Automation",
  "API & Integrations",
];

const questions = [
  "What is NetNexx?",
  "What network vendors does NetNexx support?",
  "Can NetNexx manage Aruba networks?",
  "Is NetNexx a network monitoring tool?",
  "Can MSPs use NetNexx?",
  "Can NetNexx monitor network devices in real time?",
  "Can NetNexx be deployed on-premise?",
  "Does NetNexx support multiple network vendors?",
];

function ProductVisual({ className = "" }: { className?: string }) {
  return (
    <div className={`product-visual ${className}`} aria-hidden="true">
      <div className="visual-topbar"><span /><span /><span /><i /></div>
      <div className="visual-body">
        <div className="visual-sidebar"><b /><b /><b /><b /><b /></div>
        <div className="visual-content">
          <div className="visual-heading" />
          <div className="visual-metrics"><i /><i /><i /></div>
          <div className="visual-chart"><span /><span /><span /><span /><span /><span /><span /><span /></div>
          <div className="visual-lines"><i /><i /><i /></div>
        </div>
      </div>
      <div className="visual-glow" />
    </div>
  );
}

export function meta() {
  return [
    { title: "NetNexx | Network operations, simplified" },
    { name: "description", content: "Manage your entire network from one powerful platform." },
  ];
}

export default function HomeRoute() {
  return (
    <main className="netnexx-page">
      <header className="site-header" data-node-id="1:563">
        <a href="#home" className="brand" aria-label="NetNexx home" data-node-id="1:565"><img className="netnexx-logo" src="/netnexx-logo.svg" alt="NetNexx" /></a>
        <nav className="main-nav" aria-label="Main navigation" data-node-id="1:586">
          <a href="#platform">Platform</a><a href="#solutions">Product</a><a href="#solutions">Solutions</a><a href="#resources">Resources</a><a href="#contact">Company</a>
        </nav>
        <div className="header-actions"><a className="header-login" href="#contact">Login</a><a className="header-cta" href="#contact">Book a demo</a></div>
      </header>

      <section className="hero-section" id="home" data-node-id="1:150">
        <div className="hero-inner">
          <div className="hero-copy">
            <div className="eyebrow" data-node-id="1:343"><span className="eyebrow-dot" /> Network Management Platform</div>
            <h1 data-node-id="1:214">Manage your<br />entire network from<br />one powerful platform</h1>
            <p data-node-id="1:215">NetNexx is a centralized network management and monitoring platform for IT teams, NOCs, and MSPs to monitor and manage multi-vendor network infrastructure from a single dashboard.</p>
            <ul className="hero-points" data-node-id="1:350"><li>Track Performance Realtime</li><li>Monitor Network Devices</li><li>Complete Network Visibility</li><li>Receive Instant Alerts</li></ul>
            <div className="hero-actions"><a className="button-primary" href="#contact" data-node-id="1:346">Book a Demo</a><a className="text-link" href="#platform">Explore More <span>↓</span></a></div>
          </div>
          <div className="hero-visual-panel" data-node-id="1:363" aria-hidden="true" />
        </div>
        <div className="hero-trust" data-node-id="1:364"><strong>Built for Modern Network Operations</strong><div className="trust-benefits"><b>Centralized Management</b><b>Real-Time Monitoring</b><b>Multi-Vendor Support</b><b>Network Visibility</b></div></div>
      </section>

      <section className="section-intro" id="platform" data-node-id="1:168">
        <h2>Network management shouldn’t be this complicated</h2>
        <p>Juggling separate consoles for every vendor slows teams down and leaves blind spots exactly where you can least afford them.</p>
        <div className="feature-cards" data-node-id="1:180">
          {capabilities.map(([title, text], index) => <article className="feature-card" key={title} data-node-id={["1:181", "1:188", "1:195"][index]}><span className="feature-icon">{["▦", "◉", "⌁"][index]}</span><h3>{title}</h3><p>{text}</p></article>)}
        </div>
      </section>

      <section className="split-section soft-section" id="solutions" data-node-id="1:381">
        <div className="split-copy"><div className="section-kicker">The Solution</div><h2>One platform for your network operations</h2><p>NetNexx provides centralized visibility into your network infrastructure, helping IT teams monitor devices, understand network health and respond to issues faster.</p></div>
        <div className="split-visual blue-visual" data-node-id="1:389" aria-hidden="true" />
      </section>

      <section className="tools-section">
        <div className="section-intro compact" data-node-id="1:171"><h2>Everything you need to monitor and manage your network</h2><p>A single set of tools that covers discovery, monitoring, alerting and reporting — built around real IT and NOC workflows.</p></div>
        <div className="tools-grid">{tools.map((tool, index) => <a href="#contact" className="tool-item" key={tool}><span className="tool-icon">{["◉", "⌘", "⌖", "◌", "⌁", "▥", "↻", "▤", "▧", "♙", "✳", "⌗"][index]}</span><span>{tool}</span><span className="tool-arrow">↗</span></a>)}</div>
      </section>

      <section className="value-section" data-node-id="1:164">
        <div className="value-heading section-intro" data-node-id="1:174"><h2>Everything you need to monitor and manage your network</h2><p>A single set of tools that covers discovery, monitoring, alerting and reporting — built around real IT and NOC workflows.</p></div>
        <div className="value-content"><div className="numbered-list"><article><b>01</b><div><h3>See your entire network at a glance</h3><p>A single dashboard view of every device, vendor and site — no switching consoles to know what's running and how it's performing.</p></div></article><article><b>02</b><div><h3>Know what's happening across network</h3><p>Real-time alerts surface the events that matter, so issues get to the right person before they become outages.</p></div></article><article><b>03</b><div><h3>Understand your network topology</h3><p>Visualize how devices connect across your infrastructure, so tracing a problem back to its source takes minutes, not hours.</p></div></article></div><div className="split-visual blue-visual tall-visual" data-node-id="1:391" aria-hidden="true" /></div>
      </section>

      <section className="dark-promo" id="resources" data-node-id="1:161"><div className="promo-inner"><div className="promo-art"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="promo-core">N</div><span className="promo-node node-one"/><span className="promo-node node-two"/><span className="promo-node node-three"/></div><div className="promo-copy"><div className="section-kicker">Your Own Network Management</div><h2>Manage your network infrastructure from NetNexx</h2><p>NetNexx provides centralized visibility and management capabilities for supported Aruba network environments, helping IT teams monitor their infrastructure from a unified operations platform.</p><a className="button-light" href="#contact">Explore NetNexx <span>→</span></a></div></div></section>

      <section className="steps-section" data-node-id="1:177"><div className="section-intro compact"><h2>From Discovery to Visibility in Three Steps</h2><p>A single set of tools that covers discovery, monitoring, alerting and reporting — built around real IT and NOC workflows.</p></div><div className="steps-visual" data-node-id="1:392"><div className="steps-screen"><div className="screen-bar"><i/><i/><i/></div><div className="screen-blocks"><i/><i/><i/><i/></div><div className="screen-graph"/></div></div><div className="steps-row"><article><b className="step-number">1</b><h3>Connect</h3><p>Connect NetNexx to your network and discover the devices within your infrastructure.</p></article><article><b className="step-number coral">2</b><h3>Monitor</h3><p>NetNexx collects and organizes network information into a centralized operational view.</p></article><article><b className="step-number green">3</b><h3>Act</h3><p>Identify issues, receive alerts, investigate problems, and take action before they impact your network.</p></article></div></section>

      <section className="deploy-section" data-node-id="1:390"><div className="section-intro compact"><h2>Deploy NetNexx where it works best for your organization</h2><p>A single set of tools that covers discovery, monitoring, alerting and reporting — built around real IT and NOC workflows.</p></div><div className="deploy-cards" data-node-id="1:449"><article><h3>Cloud</h3><p>Run NetNexx as a fully hosted service with no infrastructure to manage.</p></article><article><h3>On-premise</h3></article><article><h3>Hybrid</h3></article></div></section>

      <section className="integrations-section" id="integrations" data-node-id="1:155"><div className="integrations-copy"><div className="section-kicker">Network Partners</div><h2>Connect with your network environment</h2><p>NetNexx provides centralized visibility into your network infrastructure, helping IT teams monitor devices, understand network health and respond to issues faster.</p></div><div className="vendor-cloud"><span className="vendor vendor-cisco">cisco</span><span className="vendor vendor-aruba">aruba</span><span className="vendor vendor-fortinet">FORTINET</span><span className="vendor vendor-aws">aws</span><span className="vendor vendor-microsoft">Microsoft</span><span className="vendor vendor-juniper">JUNIPER</span><span className="vendor vendor-palo">paloalto</span><span className="vendor vendor-azure">azure</span></div></section>

      <section className="demo-band" data-node-id="1:162"><div className="demo-heading"><h2>See NetNexx in action</h2><p>A single set of tools that covers discovery, monitoring, alerting and reporting — built around real IT and NOC workflows.</p><div className="demo-tabs"><button className="active">Overview</button><button>Visibility</button><button>Automation</button><button>Insights</button></div></div><a className="video-card" href="#contact" aria-label="Watch the NetNexx overview"><div className="video-top"><span>NETNEXX PLATFORM OVERVIEW</span><span>02:14</span></div><span className="play-button">▶</span><span className="video-bottom">Discover the NetNexx platform</span></a></section>

      <section className="approach-section" data-node-id="1:443"><div className="section-intro compact"><h2>A smarter approach to network operations</h2><p>A single set of tools that covers discovery, monitoring, alerting and reporting — built around real IT and NOC workflows.</p></div><div className="approach-panels" data-node-id="1:227"><div className="approach-list"><b>Multiple management consoles</b><b>Vendor-specific workflows</b><b>Manual monitoring</b><b>Scattered alerts</b><b>Difficult reporting</b></div><div className="approach-blue"><span>WITH NETNEXX</span><div className="approach-checks"><b>Centralized visibility</b><b>Multi-vendor approach</b><b>Automated monitoring</b><b>Centralized alerts</b><b>Centralized reporting</b></div></div></div></section>

      <section className="faq-section" data-node-id="1:508"><div className="section-intro compact"><h2>Frequently asked questions</h2></div><div className="faq-list">{questions.map((q, i) => <details key={q} open={i === 0}><summary>{q}<span>{i === 0 ? "−" : "+"}</span></summary>{i === 0 && <p>NetNexx is a network management and monitoring platform designed to provide centralized visibility and operational capabilities across supported network infrastructure.</p>}</details>)}</div></section>

      <footer className="site-footer" id="contact" data-node-id="1:163"><div className="footer-cta" data-node-id="1:266"><div><h2>Take control of your network operations</h2><p>Get centralized visibility across your network infrastructure with NetNexx.</p></div><div className="footer-actions"><a className="button-light" href="mailto:hello@netnexx.com">Book a Demo</a><a className="footer-secondary-cta" href="#platform">Explore More</a></div></div><div className="footer-main" data-node-id="1:274"><div className="footer-brand-column"><a href="#home" className="brand footer-brand"><span className="brand-colors"><i/><i/><i/><i/></span><span>NetNexx</span></a><p className="footer-tagline">Intelligent software solutions for modern businesses, by SellNexx.</p></div><div className="footer-links"><div><b>PRODUCT</b><a href="#platform">Overview</a><a href="#solutions">Capabilities</a><a href="#integrations">Integrations</a></div><div><b>SOLUTIONS</b><a href="#solutions">Network teams</a><a href="#solutions">IT operations</a><a href="#solutions">Enterprise</a></div><div><b>RESOURCES</b><a href="#resources">Why NetNexx</a><a href="#resources">Get started</a><a href="#contact">Contact</a></div><div><b>COMPANY</b><a href="#contact">About us</a><a href="#contact">Careers</a><a href="#contact">Get in touch</a></div></div></div><div className="footer-legal"><span>© 2026 SellNexx. All rights reserved.</span><span><a href="#contact">Privacy Policy</a><a href="#contact">Terms of Service</a><a href="#contact">Security</a></span></div></footer>
    </main>
  );
}
