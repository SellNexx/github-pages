
import React from 'react';
import { Twitter, Linkedin, Instagram, Mail } from 'lucide-react';

const SocialLinks = () => {
  const socialLinks = [
    {
      icon: Twitter,
      href: '#',
      label: 'Twitter',
      color: 'hover:text-gray-300'
    },
    {
      icon: Linkedin,
      href: '#',
      label: 'LinkedIn',
      color: 'hover:text-gray-300'
    },
    {
      icon: Instagram,
      href: '#',
      label: 'Instagram',
      color: 'hover:text-gray-300'
    },
    {
      icon: Mail,
      href: 'mailto:hello@sellnexx.com',
      label: 'Email',
      color: 'hover:text-gray-300'
    }
  ];

  return (
    <div className="flex space-x-8 justify-center">
      {socialLinks.map((link) => (
        <a
          key={link.label}
          href={link.href}
          className={`text-gray-500 ${link.color} transition-all duration-300 transform hover:scale-110 hover:-translate-y-1`}
          aria-label={link.label}
        >
          <link.icon size={28} strokeWidth={1.5} />
        </a>
      ))}
    </div>
  );
};

export default SocialLinks;
