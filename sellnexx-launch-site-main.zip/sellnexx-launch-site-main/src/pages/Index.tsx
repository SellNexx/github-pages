
import React from 'react';
import Newsletter from '@/components/Newsletter';
import SocialLinks from '@/components/SocialLinks';

const Index = () => {
  return (
    <div className="min-h-screen bg-black relative overflow-hidden">
      {/* Subtle background gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-gray-900/20 via-black to-gray-900/20"></div>
      
      {/* Animated background elements */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-white/5 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-gray-700/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-white/3 rounded-full blur-2xl animate-pulse delay-500"></div>
      </div>

      {/* Main content */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-4 text-center">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Logo/Brand */}
          <div className="animate-fade-in">
            <h1 className="text-7xl md:text-9xl font-bold text-white mb-4 tracking-tight">
              Sell<span className="text-transparent bg-clip-text bg-gradient-to-r from-gray-300 to-gray-500">Nexx</span>
            </h1>
          </div>

          {/* Coming Soon Badge */}
          <div className="animate-fade-in delay-300">
            <div className="inline-flex items-center px-8 py-4 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full">
              <div className="w-3 h-3 bg-green-400 rounded-full mr-4 animate-pulse"></div>
              <span className="text-white font-semibold text-lg">Coming Soon 2025</span>
            </div>
          </div>

          {/* Tagline */}
          <div className="animate-fade-in delay-500">
            <p className="text-2xl md:text-3xl text-gray-300 font-light max-w-3xl mx-auto leading-relaxed">
              The next generation selling platform.
              <span className="block mt-3 text-gray-400 text-xl">Revolutionizing the way you sell.</span>
            </p>
          </div>

          {/* Description */}
          <div className="animate-fade-in delay-700">
            <p className="text-lg text-gray-400 max-w-2xl mx-auto mb-12 leading-relaxed">
              Join thousands of sellers preparing for the ultimate platform that combines 
              simplicity, power, and innovation. Be among the first to experience the future of selling.
            </p>
          </div>

          {/* Newsletter Signup */}
          <div className="animate-fade-in delay-900">
            <h3 className="text-2xl font-semibold text-white mb-6">Get Early Access</h3>
            <Newsletter />
            <p className="text-sm text-gray-500 mt-4">
              No spam, unsubscribe at any time. We respect your privacy.
            </p>
          </div>

          {/* Social Links */}
          <div className="animate-fade-in delay-1100">
            <h4 className="text-lg text-gray-300 mb-6">Follow our journey</h4>
            <SocialLinks />
          </div>
        </div>

        {/* Footer */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
          <p className="text-gray-600 text-sm">
            © 2025 SellNexx. All rights reserved.
          </p>
        </div>
      </div>

      {/* Decorative top border */}
      <div className="absolute top-0 left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-gray-400 to-transparent"></div>
    </div>
  );
};

export default Index;
